;;; Generated package description from org-link-archive.el  -*- no-byte-compile: t -*-
(define-package "org-link-archive" "20230825.50831" "A package for archiving web pages" 'nil :keywords '("tools" "web" "org") :url "https://github.com/adamWithF")
