;;; Generated package description from org-imagine.el  -*- no-byte-compile: t -*-
(define-package "org-imagine" "20240825.174353" "an org element visualization decorator" 'nil)
