(define-package "osm" "20240122.2255" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "5dffbc00e4acfcddc13677f3b76a65dc3b6aee30" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
