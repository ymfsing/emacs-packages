(define-package "meow" "20240229.50" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "0d74ccfb7f1ebf987e34eb0b656ceb991367a987" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
