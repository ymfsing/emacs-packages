;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20241122.130"
  "OpenStreetMap viewer."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "6a2416dc4c3be22573cd9f5fb285df3f4bd6b6ea"
  :revdesc "6a2416dc4c3b"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
