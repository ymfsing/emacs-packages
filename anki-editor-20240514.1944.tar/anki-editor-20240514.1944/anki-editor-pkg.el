(define-package "anki-editor" "20240514.1944" "Minor mode for making Anki cards with Org"
  '((emacs "25.1"))
  :commit "32d81be1d8305c5ccde12c7d0b29845d4f831888" :authors
  '(("Lei Tan"))
  :maintainers
  '(("Lei Tan"))
  :maintainer
  '("Lei Tan")
  :url "https://github.com/anki-editor/anki-editor")
;; Local Variables:
;; no-byte-compile: t
;; End:
