(define-package "meow" "20240613.2044" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "bc05b048d3582425717d114b837b8fe78d47a753" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
