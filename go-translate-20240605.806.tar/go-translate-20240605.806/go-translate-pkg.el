(define-package "go-translate" "20240605.806" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "64a01dc5cc1cbf1b79edbd970a94661f1a4dad90" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
