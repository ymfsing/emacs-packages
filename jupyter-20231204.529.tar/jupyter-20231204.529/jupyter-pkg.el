(define-package "jupyter" "20231204.529" "Jupyter"
  '((emacs "26")
    (cl-lib "0.5")
    (org "9.1.6")
    (zmq "0.10.10")
    (simple-httpd "1.5.0")
    (websocket "1.9"))
  :commit "da306a6dbda6f1e285281765a311938a1d9db022" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :url "https://github.com/emacs-jupyter/jupyter")
;; Local Variables:
;; no-byte-compile: t
;; End:
