;; Generated package description from cape.el  -*- no-byte-compile: t -*-
(define-package "cape" "0.12" "Completion At Point Extensions" '((emacs "27.1")) :commit "0bbe3620d6b04f07124b6cde3d979252bdc5782d" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/cape")
