(define-package "citre" "20221205.938" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "86c346b357a4486d38d15a41fa31d86f7dd0bc57" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
