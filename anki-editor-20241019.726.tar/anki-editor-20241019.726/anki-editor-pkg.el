;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20241019.726"
  "Minor mode for making Anki cards with Org."
  '((emacs "25.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "dc0111527b99445689ec043ae9a8a7d8504c4949"
  :revdesc "dc0111527b99")
