;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241031.1213"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "f9a6b5ff427dbe53fd8d2f52bc819a255ec21e6a"
  :revdesc "f9a6b5ff427d"
  :keywords '("convenience" "modal-editing"))
