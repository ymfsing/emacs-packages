(define-package "mcp" "20250727.154947"
  "Model Context Protocol" '((emacs "30.1") (jsonrpc "1.0.25"))
  :authors '(("lizqwer scott" . "lizqwerscott@gmail.com")) :maintainer
  '("lizqwer scott" . "lizqwerscott@gmail.com") :keywords '("tools")
  :url "https://github.com/lizqwerscott/mcp.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
