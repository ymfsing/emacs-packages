;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jupyter" "20241004.241"
  "Jupyter."
  '((emacs        "26")
    (cl-lib       "0.5")
    (org          "9.1.6")
    (zmq          "0.10.10")
    (simple-httpd "1.5.0")
    (websocket    "1.9"))
  :url "https://github.com/emacs-jupyter/jupyter"
  :commit "674af0481a94f2ce56c62aa7668a966254ef26ef"
  :revdesc "674af0481a94"
  :authors '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainers '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")))
