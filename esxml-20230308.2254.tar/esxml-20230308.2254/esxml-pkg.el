;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "esxml" "20230308.2254"
  "Library for working with xml via esxml and sxml."
  ()
  :url "https://github.com/tali713/esxml"
  :commit "225693096a587492d76bf696d1f0c25c61f7d531"
  :revdesc "225693096a58"
  :keywords '("tools" "lisp" "comm")
  :authors '(("Vanya Izaksonas-Smith" . "izak0002atumndotedu")))
