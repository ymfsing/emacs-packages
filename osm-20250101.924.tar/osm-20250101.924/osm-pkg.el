;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20250101.924"
  "OpenStreetMap viewer."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "fa52c07484bb5ce57b066c7e59783be3f45205a2"
  :revdesc "fa52c07484bb"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
