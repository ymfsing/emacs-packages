;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20250101.945"
  "Minor mode for making Anki cards with Org."
  '((emacs "25.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "75367008d43d5c120341b3511c4a098b7abd5cbc"
  :revdesc "75367008d43d")
