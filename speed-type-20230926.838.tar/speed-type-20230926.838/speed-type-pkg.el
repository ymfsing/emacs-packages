;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20230926.838"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "28b8e8c1cc24511758168f30bcac18d8fb93706d"
  :revdesc "28b8e8c1cc24"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
