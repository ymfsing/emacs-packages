;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250101.2053"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "046e7836f81385ff57a61bd9a1fc23026cec8ede"
  :revdesc "046e7836f813"
  :keywords '("languages"))
