;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa" "20230620.1343"
  "Emacs Lisp packages built directly from source."
  '((emacs "25.1"))
  :url "https://github.com/quelpa/quelpa"
  :commit "b6a73d4e9e06631d2adb7bfbd83bbe7ee4211809"
  :revdesc "b6a73d4e9e06"
  :keywords '("tools" "package" "management" "build" "source" "elpa"))
