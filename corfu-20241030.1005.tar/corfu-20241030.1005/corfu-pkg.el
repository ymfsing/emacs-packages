;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20241030.1005"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "84a6ece9f6ab3b94e932cfbfe6970a21b59d975c"
  :revdesc "84a6ece9f6ab"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
