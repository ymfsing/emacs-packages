(define-package "keycast" "20240225.2105" "Show current command and its binding"
  '((emacs "25.3")
    (compat "29.1.4.1"))
  :commit "7fe65f1b9b8b3e8999cd27119db37cb0ec29699d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("multimedia")
  :url "https://github.com/tarsius/keycast")
;; Local Variables:
;; no-byte-compile: t
;; End:
