;;; Generated package description from fingertip.el  -*- no-byte-compile: t -*-
(define-package "fingertip" "20230918.211733" "Fingertip is struct edit plugin that base on treesit" 'nil :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com")) :maintainer '("Andy Stewart" . "lazycat.manatee@gmail.com") :url "https://www.github.com/manateelazycat/fingertip")
