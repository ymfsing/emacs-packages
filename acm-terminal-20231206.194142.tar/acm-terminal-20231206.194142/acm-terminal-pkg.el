;;; Generated package description from acm-terminal.el  -*- no-byte-compile: t -*-
(define-package "acm-terminal" "20231206.194142" "Patch for LSP bridge acm on Terminal" '((emacs "26.1")) :authors '(("Gong Qijian" . "gongqijian@gmail.com")) :maintainer '("Gong Qijian" . "gongqijian@gmail.com") :url "https://github.com/twlz0ne/acm-terminal")
