;;; Generated package description from org-noter-plus.el  -*- no-byte-compile: t -*-
(define-package "org-noter-plus" "20230916.193608" "extract outline and annotations from doc" 'nil :url "https://github.com/yuchen-lea/org-noter-plus")
