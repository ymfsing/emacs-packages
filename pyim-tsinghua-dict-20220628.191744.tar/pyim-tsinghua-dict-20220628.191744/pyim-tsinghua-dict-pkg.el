(define-package "pyim-tsinghua-dict" "20220628.191744"
  "tsinghua pinyin (quanpin) dict for pyim." '((pyim "3.7")) :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com")) :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com") :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete") :url
  "https://github.com/redguardtoo/pyim-tsinghua-dict")
;; Local Variables:
;; no-byte-compile: t
;; End:
