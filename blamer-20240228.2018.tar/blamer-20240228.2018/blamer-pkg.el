(define-package "blamer" "20240228.2018" "Show git blame info about current line"
  '((emacs "27.1")
    (posframe "1.1.7")
    (async "1.9.8"))
  :commit "5c4495283d5c40f6c5997931f01544532ae2d85e" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/artawower/blamer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
