;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250711.534"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "736c2d1888644b2cea172a6fc12dbf7840101405"
  :revdesc "736c2d188864"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
