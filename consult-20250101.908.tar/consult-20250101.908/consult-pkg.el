;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250101.908"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "89efd2cb733af27a655dfaafeafdd4e155ac54a4"
  :revdesc "89efd2cb733a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
