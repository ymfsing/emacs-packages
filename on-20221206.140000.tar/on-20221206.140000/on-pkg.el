;;; Generated package description from on.el  -*- no-byte-compile: t -*-
(define-package "on" "20221206.140000" "Hooks for faster startup" '((emacs "27.1")) :authors '(("Alex Griffin" . "a@ajgrf.com")) :maintainer '("Alex Griffin" . "a@ajgrf.com") :keywords '("convenience") :url "https://gitlab.com/ajgrf/on.el")
