;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-dir" "20240506.236"
  "Insert paths into the minibuffer prompt."
  '((emacs   "27.1")
    (consult "1.0"))
  :url "https://github.com/karthink/consult-dir"
  :commit "15891383f34d43acc5bb82bda92239b1f54cf178"
  :revdesc "15891383f34d"
  :keywords '("convenience")
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
