;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20250723.920"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "0a889b50922af6b1fb5086ceaa344b3201e8547e"
  :revdesc "0a889b50922a")
