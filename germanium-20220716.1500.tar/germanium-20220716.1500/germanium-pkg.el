(define-package "germanium" "20220716.1500" "Generate image from source code using germanium"
  '((emacs "26.1"))
  :commit "7292aa6870cf8b0acb34a8750da32b44d83cd65c" :authors
  '(("Masaya Watanabe"))
  :maintainers
  '(("Masaya Watanabe"))
  :maintainer
  '("Masaya Watanabe")
  :keywords
  '("convenience")
  :url "https://github.com/matsuyoshi30/germanium-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
