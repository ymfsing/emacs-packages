;;; Generated package description from clue.el  -*- no-byte-compile: t -*-
(define-package "clue" "20220531.1031" "Connecting clues while reading code" 'nil :authors '(("Hao WANG" . "amaikinono@gmail.com")) :maintainer '("Hao WANG" . "amaikinono@gmail.com") :keywords '("convenience" "tools") :url "https://github.com/AmaiKinono/clue")
