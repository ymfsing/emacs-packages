;; Generated package description from meow.el  -*- no-byte-compile: t -*-
(define-package "meow" "1.4.2" "Yet Another modal editing" '((emacs "27.1")) :commit "57656a69d3c29ddb0d18697491f80674e1097eaf" :authors '(("Shi Tianshu")) :maintainer '("Shi Tianshu") :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
