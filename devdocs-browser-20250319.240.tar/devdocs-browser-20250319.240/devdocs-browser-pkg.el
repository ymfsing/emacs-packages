;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs-browser" "20250319.240"
  "Browse devdocs.io documents using EWW."
  '((emacs "27.1"))
  :url "https://github.com/blahgeek/emacs-devdocs-browser"
  :commit "e6ccbaafc795e8be54762b2e930ada2967cec08b"
  :revdesc "e6ccbaafc795"
  :keywords '("docs" "help" "tools")
  :authors '(("blahgeek" . "i@blahgeek.com"))
  :maintainers '(("blahgeek" . "i@blahgeek.com")))
