;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpv" "20220801.1917"
  "Control mpv for easy note-taking."
  '((emacs "25.1"))
  :url "https://github.com/kljohann/mpv.el"
  :commit "2e0234bc21a3dcdf12d94d3285475e7f6769d3e8"
  :revdesc "2e0234bc21a3"
  :keywords '("tools" "multimedia")
  :authors '(("Johann Klähn" . "johann@jklaehn.de"))
  :maintainers '(("Johann Klähn" . "johann@jklaehn.de")))
