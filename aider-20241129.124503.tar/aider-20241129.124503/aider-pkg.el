(define-package "aider" "20241129.124503" "Aider package for interactive conversation with aider"
  '((emacs "25.1")
    (transient "0.3.0"))
  :authors
  '(("Kang Tu" . "tninja@gmail.com"))
  :maintainer
  '("Kang Tu" . "tninja@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/tninja/aider.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
