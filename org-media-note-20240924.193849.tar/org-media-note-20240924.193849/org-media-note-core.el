;;; org-media-note-core.el --- Core for org-mode-note -*- lexical-binding: t; -*-


;;; Commentary:

;;; Code:
;;;; Requirements
(require 'mpv)
(require 'org)

(require 'cl-lib)

(declare-function org-element-context "org-element" (&optional element))
(declare-function org-element-property "org-element-ast" (property node &optional dflt force-undefer))
(declare-function org-element-type "org-element-ast" (node &optional anonymous))
(declare-function org-timer-secs-to-hms "org-timer" (s))
(declare-function org-timer-hms-to-secs "org-timer" (hms))
(declare-function org-attach-dir "org-attach")

(declare-function org-media-note-cite--file-path "org-media-note-org-ref" (key))
(declare-function org-media-note-cite--url "org-media-note-org-ref" (key))

;;;; Constants

(defconst org-media-note--video-types '("avi" "rmvb" "ogg" "ogv" "mp4" "mkv" "mov" "webm" "flv" "ts" "mpg"))
(defconst org-media-note--audio-types '("flac" "mp3" "wav" "m4a" "aac" "opus"))
(defconst org-media-note--hms-timestamp-pattern "\\([0-9]+:[0-9]+:[0-9]+\\)[ \t]?")
(defconst org-media-note--hmsf-timestamp-pattern "\\([0-9]+:[0-9]+:[0-9]+\\(\\.\\|,\\)[0-9]+\\)[ \t]?")
(defconst org-media-note--link-pattern "\\[\\[\\(?:audiocite\\|videocite\\|audio\\|video\\):[^]]+\\]\\[[^]]+\\]\\]")
(defconst org-media-note--list-full-item-re
  (concat "^[ \t]*\\(\\(?:[-+*]\\|\\(?:[0-9]+\\|[A-Za-z]\\)[.)]\\)\\(?:[ \t]+\\|$\\)\\)"
          "\\(?:\\[@\\(?:start:\\)?\\([0-9]+\\|[A-Za-z]\\)\\][ \t]*\\)?"
          "\\(\\(?:\\[[ X-]\\]\\(?:[ \t]+\\|$\\)\\)?" "\\(?:" org-media-note--link-pattern "\\)\\(?:[ \t]*\\|$\\)\\)?"
          "\\(?:\\(.*\\)[ \t]+::\\(?:[ \t]+\\|$\\)\\)?")
  "Matches a list item and puts everything into groups:
group 1: bullet
group 2: counter
group 3: checkbox + link
group 4: description tag")

;;;; Customization

(defgroup org-media-note nil
  "Taking video and audio notes with Org-mode."
  :group 'org
  :prefix "org-media-note-")

(defcustom org-media-note-auto-insert-item t
  "Control whether to automatically insert media items in `org-media-note-mode'."
  :type 'boolean)

(defcustom org-media-note-pause-after-insert-link nil
  "When non-nil, pause the media after inserting timestamp link."
  :type 'boolean)

(defcustom org-media-note-cursor-start-position 'after
  "Determine where to position point after inserting a link."
  :type 'symbol
  :options '(before after))

(defcustom org-media-note-separator-when-merge ""
  "Separator to use when calling  `org-media-note-merge-item'."
  :type 'string)

(defcustom org-media-note-select-function
  (cond
   ((fboundp 'ido-completing-read) 'ido-completing-read)
   (t 'completing-read))
  "Function to use for selection in org-media-note."
  :type '(choice
          (const :tag "ido-completing-read" ido-completing-read)
          (const :tag "completing-read" completing-read)))

(defcustom org-media-note-interface 'transient
  "The interface to use for org-media-note."
  :type '(choice
          (const :tag "pretty-hydra" pretty-hydra)
          (const :tag "transient" transient)))


(defcustom org-media-note-interface-display-browse-url t
  "When non-nil, display browse url command in transient."
  :type 'boolean)

;;;;; link format customization

(defcustom org-media-note-timestamp-pattern 'hms
  "Format pattern for timestamps in org-media-note.
Allows the following substitutions:
- `hms`: Hours, minutes, and seconds (hh:mm:ss).
- `hmsf`: Hours, minutes, seconds, and milliseconds (hh:mm:ss.fff)."
  :type '(choice
          (const :tag "hh:mm:ss" hms)
          (const :tag "hh:mm:ss.fff" hmsf)))

(defcustom org-media-note-timestamp-link-format "%timestamp"
  "Timestamp Link description.
Allows the following substitutions:
- %filename :: name of the media file
- %timestamp :: current media timestamp (hms)
- %file-path :: path of the media file"
  :type 'string)

(defcustom org-media-note-ab-loop-link-format "%ab-loop-a-%ab-loop-b"
  "AB-loop Link description.
Allows the following substitutions:
- %filename :: name of the media file
- %ab-loop-a :: timestamp of point a of ab loop (hms)
- %ab-loop-b :: timestamp of point b of ab loop (hms)
- %file-path :: path of the media file"
  :type 'string)

(defcustom org-media-note-link-prefix ""
  "String concatenated to the beginning of links.
e.g. setting this to \" \" will insert a space before the link.
This is useful when `org-media-note-cursor-start-position' is set to`before`."
  :type 'string)

(defcustom org-media-note-desc-fn #'org-media-note--default-desc-fn
  "Function to generate link descriptions when exporting.
Based on path, timestamp and desc."
  :type 'function)

(defcustom org-media-note-utm-parameter-patterns '("utm_" "si" "share_" ".*source=" ".*id=" "is_" "unique_")
  "List of UTM parameter patterns to be removed from URLs."
  :type '(repeat string))

;;;;; org-ref customization

(defcustom org-media-note-use-org-ref nil
  "Whether to use `org-ref' together with org-media-note."
  :type 'boolean)

(defcustom org-media-note-use-refcite-first nil
  "When non-nil, use refcite instead of file path when taking notes if possible."
  :type 'boolean)

(defcustom org-media-note-ref-key-field "Custom_ID"
  "The property to save `org-ref' key."
  :type 'string)

(defcustom org-media-note-use-inheritance t
  "Ref key inheritance for the outline."
  :type '(choice
          (const :tag "Don't use inheritance" nil)
          (const :tag "Inherit parent node ref key" t)))

;;;;; screenshot customization

(defcustom org-media-note-screenshot-save-method 'directory
  "The way images should be stored.
1. directory: save to `org-media-note-screenshot-image-dir'
2. attach: save to corresponding `org-attach-dir'.
3. custom function: save to dir returned by function,
accept two arguments: media-path, media-title."
  :type '(choice (const :tag "Directory" directory)
          (const :tag "Attachment" attach)
          (function :tag "Custom function")))

(defcustom org-media-note-screenshot-link-type-when-save-in-attach-dir 'file
  "Link type to use with the `attach` `org-media-note-screenshot-save-method'.
File links are more general, while attachment links are more concise."
  :type '(choice
          (const :tag "file:" file)
          (const :tag "attachment:" attach)))

(defcustom org-media-note-screenshot-image-dir org-directory
  "Default dir to save screenshots.
Only valid when `org-media-note-screenshot-save-method' is set to directory."
  :type 'string)

(defcustom org-media-note-screenshot-extension ".jpg"
  "File extension for screenshots taken with org-media-note.
Should be consistent with `screenshot-format' in MPV."
  :type 'string)

(defcustom org-media-note-capture-name-function
  'org-media-note--capture-name-function-default
  "Function to format screenshot or clip names in org-media-note."
  :type 'function)

(defcustom org-media-note-save-screenshot-p nil
  "Whether to auto save screenshot when insert media link."
  :type 'boolean)

(defcustom org-media-note-screenshot-with-sub t
  "When saving screenshots, whether to save subtitles."
  :type 'boolean)

(defcustom org-media-note-display-inline-images t
  "When non-nil, display inline images in org buffer after insert screenshot."
  :type 'boolean)

;;;;; capture-ab-loop customization

(defcustom org-media-note-capture-ab-loop-ask-each-time t
  "If non-nil, select capture function each time capturing an ab-loop.
Otherwise, use the preset function."
  :type 'boolean)

(defcustom org-media-note-capture-ab-loop-functions-alist
  '(("clip-copy" . org-media-note-capture-ab-loop-default)
    ("gif" . org-media-note-capture-ab-loop-to-gif))
  "Alist of functions to capture ab-loop segments and their descriptions."
  :type '(alist
          :key-type string
          :value-type function))

(defcustom org-media-note-default-capture-ab-loop-function-name "clip-copy"
  "Default function used for capturing ab-loop segments."
  :type 'string)

;;;;; mpv customization

(defcustom org-media-note-seek-method 'seconds
  "Method used for seeking. Possible values are 'seconds, 'percentage, 'frames."
  :type 'symbol
  :options '(seconds percentage frames))

(defcustom org-media-note-seek-value 5
  "Value used for seeking, interpretation depends on `org-media-note-seek-method`."
  :type 'number)

(defcustom org-media-note-mpv-webstream-download-path
  (expand-file-name "yt-dlp" temporary-file-directory)
  "Path where mpv webstream files are to be stored.
Set this to nil if you prefer to save files in current directory."
  :type 'string)

(defcustom org-media-note-mpv-general-options
  '("--script-opts=ytdl_hook-ytdl_path=yt-dlp")
  "General MPV options."
  :type '(repeat string))

(defcustom org-media-note-mpv-online-website-options-alist nil
  "Alist of website regex patterns and their corresponding mpv options."
  :type '(alist
          :key-type (regexp :tag "Website Regex")
          :value-type (repeat (string :tag "MPV Option"))))

;;;; Commands
;;;;; Utils

(defun org-media-note--select (prompt choices)
  "PROMPT the user to select from CHOICES using `org-media-note-select-function'."
  (pcase org-media-note-select-function
    ('ido-completing-read
     (ido-completing-read (format "%s: " prompt) choices))
    (_
     (completing-read (format "%s: " prompt) choices))))

(defun org-media-note--seconds-to-timestamp (secs)
  "Convert SECS (float or int) to timestamp.
according to `org-media-note-timestamp-pattern'."
  (let ((secs (if (stringp secs)
                  (string-to-number secs)
                secs)))
    (cond
     ((eq org-media-note-timestamp-pattern 'hms)
      (org-media-note--seconds-to-hms secs))
     ((eq org-media-note-timestamp-pattern 'hmsf)
      (org-media-note--seconds-to-hmsf secs)))))

(defun org-media-note--seconds-to-hms (secs)
  "Convert SECS (float or int) to hh:mm:ss."
  (org-timer-secs-to-hms (round secs)))

(defun org-media-note--seconds-to-hmsf (secs)
  "Convert SECS (float or int) to hh:mm:ss.fff."
  (let* ((sec-with-ms (split-string (format "%0.3f" secs) "\\."))
         (sec (string-to-number (car sec-with-ms)))
         (ms (nth 1 sec-with-ms)))
    (format "%s.%s" (org-timer-secs-to-hms sec) ms)))

(defun org-media-note--millisecs-to-timestamp (millisecs)
  "Convert MILLISECS to timestamp."
  (let ((millisecs (if (stringp millisecs)
                       (string-to-number millisecs)
                     millisecs)))
    (org-media-note--seconds-to-timestamp (/ millisecs 1000.0))))

(defun org-media-note--get-duration-timestamp ()
  "Get the current media duration timestamp according to `org-media-note-timestamp-pattern'."
  (org-media-note--seconds-to-timestamp (mpv-get-duration)))

(defun org-media-note--get-current-timestamp ()
  "Get current media timestamp according to `org-media-note-timestamp-pattern'."
  (let ((position (mpv-get-playback-position)))
    (if position
        (org-media-note--seconds-to-timestamp position)
      nil)))

(defun org-media-note--timestamp-to-seconds (timestamp &optional omit-decimal)
  "Convert TIMESTAMP to seconds (string).
If OMIT-DECIMAL is non-nil, return the integer part only."
  (let* ((splitted-timestamp (split-string timestamp "\\(\\.\\|,\\)"))
         (hms (nth 0 splitted-timestamp))
         fff)
    (if (and (not omit-decimal)
             (= (length splitted-timestamp) 2))
        (progn
          (setq fff (nth 1 splitted-timestamp))
          (format "%s.%s"
                  (org-timer-hms-to-secs hms)
                  fff))
      (int-to-string (org-timer-hms-to-secs hms)))))

(defun org-media-note--current-org-ref-key ()
  "Return the `org-ref' key of current org entry."
  (org-entry-get (point) org-media-note-ref-key-field org-media-note-use-inheritance))

(defun org-media-note--current-media-type ()
  "Get current playing media type."
  (let* ((file-path (mpv-get-property "path")))
    (if (org-media-note--online-video-p file-path)
        "video" ;; TODO online audio?
      (org-media-note--file-media-type file-path))))

(defun org-media-note--file-media-type (file-path)
  "Get media type of file at FILE-PATH."
  (let* ((file-ext (if file-path
                       (file-name-extension file-path))))
    (or
     (org-media-note--get-media-type file-ext)
     ;; if format is not known, video is better than nil
     "video")))

(defun org-media-note--get-media-type (file-ext)
  "Return media type based off of FILE-EXT."
  (cond
   ((member file-ext org-media-note--video-types) "video")
   ((member file-ext org-media-note--audio-types) "audio")
   (t nil)))

(defun org-media-note-ref-cite-p ()
  "Return t if refcite link should be used instead of file path, nil otherwise."
  (and (org-media-note--current-org-ref-key)
       org-media-note-use-refcite-first))

(defun org-media-note--online-video-p (path)
  "Return t if PATH is an online video link."
  (and path (string-match "^http" path)))

(defun org-media-note--media-files-in-dir (dir)
  "Get supported media file list in DIR.
Return realpath instead of symlink."
  (mapcar #'file-truename
          (directory-files
           dir
           'full
           (rx (eval (cons 'or
                           (append org-media-note--video-types org-media-note--audio-types)))
               eos))))

(defun org-media-note--capture-name-function-default (media-path title time-a time-b extension)
  "Default function to format screenshot or clip file name.
- MEDIA-PATH: file path or url.
- TITLE: for online media and cite media only.
- TIME-A, TIME-B: e.g. '3:43:12'.
- EXTENSION: default `org-media-note-screenshot-extension'."
  (let* ((base-name (or title (file-name-base media-path)))
         (time-part (if time-b
                        (concat time-a "--" time-b)
                      time-a))
         (formatted-name (concat base-name
                                 "-"
                                 time-part))
         (replacements '((" - " "-")
                         ("[\]\[\/：:*?\"<>|+=,\\ ]" "_")
                         ("_+" "_")))
         (final-name (cl-reduce (lambda (name pair)
                                  (replace-regexp-in-string (nth 0 pair)
                                                            (nth 1 pair)
                                                            name))
                                replacements
                                :initial-value formatted-name)))
    (concat final-name extension)))

(defun org-media-note--output-file-path (file-name media-path media-title)
  "Get the output path based on the current configuration.
FILE-NAME is the name of the file to save.
MEDIA-PATH is the path to the current media file, used for some save methods.
MEDIA-TITLE is the title of the current media, used for some save methods."
  (cond
   ((eq org-media-note-screenshot-save-method
        'attach)
    (expand-file-name file-name
                      (org-attach-dir t)))
   ((eq org-media-note-screenshot-save-method
        'directory)
    (let ((dir org-media-note-screenshot-image-dir))
      (unless (file-exists-p dir)
        (make-directory dir t))
      (expand-file-name file-name dir)))
   ((fboundp org-media-note-screenshot-save-method)
    (expand-file-name file-name
                      (funcall org-media-note-screenshot-save-method
                               media-path media-title)))
   (t (error "Invalid org-media-note-screenshot-save-method"))))

(defun org-media-note--format-file-path (path)
  "Convert PATH into the format defined by `org-link-file-path-type'."
  (cond
   ((eq org-link-file-path-type 'absolute)
    (abbreviate-file-name (expand-file-name path)))
   ((eq org-link-file-path-type 'noabbrev)
    (expand-file-name path))
   ((eq org-link-file-path-type 'relative)
    (file-relative-name path))
   ((eq org-link-file-path-type 'adaptive)
    (save-match-data (if (string-match (concat "^"
                                               (regexp-quote (expand-file-name (file-name-as-directory default-directory))))
                                       (expand-file-name path))
                         ;; We are linking a file with relative path name.
                         (substring (expand-file-name path)
                                    (match-end 0))
                       (abbreviate-file-name (expand-file-name path)))))
   ((functionp org-link-file-path-type)
    (funcall org-link-file-path-type
             (expand-file-name path)))))

(defun org-media-note--insert-file-link (file-path)
  "Insert a link to FILE-PATH using the appropriate method."
  (if (and (eq org-media-note-screenshot-save-method 'attach)
           (eq org-media-note-screenshot-link-type-when-save-in-attach-dir 'attach))
      (insert (format "[[attachment:%s]]"
                      (file-relative-name file-path (org-attach-dir))))
    (insert (format "[[file:%s]]"
                    (org-media-note--format-file-path file-path)))))

;;;;;; Context
(defun org-media-note--ref-context ()
  "Return a list with info about the reference in org-media-note.
This list includes the following elements:
- use `org-ref' mode or not.
- current reference key, if available.
- associated media file for the current ref key, if any.
- associated media URL for the current ref key, if any."
  (let ((key (org-media-note--current-org-ref-key)))
    (if (org-media-note-ref-cite-p)
        (list t
              key
              (org-media-note-cite--file-path key)
              (org-media-note-cite--url key))
      (list nil nil nil nil))))

(defun org-media-note--link-context ()
  "Return a list with info about the link at point.
This list includes the following elements:
- link type.
- file absolute path or URL path.
- start time if available.
- end time if available."
  (let ((element (org-element-context)))
    (if (eq (org-element-type element) 'link)
        (let* ((link-type (org-element-property :type element))
               (link-path (org-element-property :path element))
               (org-yt-type (or (bound-and-true-p org-yt-url-protocol)
                                "yt"))
               (supported-link (member link-type `("file" "http" "https" "attachment" "audio"
                                                   "video" "audiocite" "videocite" ,org-yt-type))))
          (if supported-link
              (if (member link-type '("audio" "video" "audiocite" "videocite"))
                  (cl-multiple-value-bind (path-or-key start-time end-time)
                      (org-media-note--split-link link-path)
                    (let ((path-or-url (cond
                                        ((member link-type '("audio" "video"))
                                         (if (org-media-note--online-video-p path-or-key)
                                             path-or-key
                                           (expand-file-name path-or-key)))
                                        ((member link-type '("audiocite" "videocite"))
                                         (org-media-note-cite--path path-or-key)))))
                      (list link-type path-or-url start-time end-time)))
                (let* ((path-with-type (format "%s:%s" link-type link-path))
                       (path-or-url (cond
                                     ((string= link-type "file")
                                      (expand-file-name link-path))
                                     ((string= link-type "attachment")
                                      (expand-file-name link-path
                                                        (org-attach-dir)))
                                     ((org-media-note--online-video-p path-with-type) path-with-type)
                                     ((string= link-type org-yt-type)
                                      (concat "https://youtu.be/" link-path))
                                     (t nil))))
                  (list link-type path-or-url nil nil)))
            (list link-type link-path nil nil)))
      (list nil nil nil nil))))

(defun org-media-note--split-link (link)
  "Split a `LINK' into path, time-a and time-b."
  (let* ((splitted (split-string link "#"))
         (timestamps (split-string (nth 1 splitted)
                                   "-"))
         (time-a (nth 0 timestamps))
         (time-b (if (= (length timestamps) 2)
                     (nth 1 timestamps))))
    (list (nth 0 splitted)
          time-a
          time-b)))

(defun org-media-note--attach-context ()
  "Return a list with info about the attachments.
This list includes the following elements:
- current attach-dir
- media files in attach-dir."
  (let ((attach-dir (org-attach-dir)))
    (if attach-dir
        (let ((media-files (org-media-note--media-files-in-dir attach-dir)))
          (list (format "%s/" attach-dir) ;; to open correct dir in `read-file-name'
                media-files))
      (list nil nil))))

(defun org-media-note--current-media-info ()
  "Return a list with current playing media information.
This list includes the following elements:
- Media file path
- Media file name
- Timestamp"
  (let* ((path (mpv-get-property "path"))
         (name (if (org-media-note-ref-cite-p)
                   (let* ((ref-key (org-media-note--current-org-ref-key))
                          (bib-entry (bibtex-completion-get-entry ref-key))
                          (title (bibtex-completion-get-value "title" bib-entry)))
                     title)
                 (if (org-media-note--online-video-p path)
                     (mpv-get-property "media-title")
                   nil)))
         (timestamp (org-media-note--get-current-timestamp)))
    (list (if (org-media-note--online-video-p path)
              (org-media-note--remove-utm-parameters path)
            path)
          name
          timestamp)))

;;;;; UI

(defun org-media-note--ui-title ()
  "Return title string for `org-media-note-show-interface'."
  (cl-multiple-value-bind (file-path title current-timestamp)
      (org-media-note--current-media-info)
    (let ((icon (cond ((fboundp 'nerd-icons-octicon)
                       (nerd-icons-octicon "nf-oct-video"))
                      ((fboundp 'all-the-icons-material)
                       (all-the-icons-material "ondemand_video"))
                      (t ""))))
      (if file-path
          ;; Title when mpv is playing media
          (let ((speed (mpv-get-property "speed"))
                (volume (mpv-get-property "volume"))
                (total-timestamp (org-media-note--get-duration-timestamp))
                (remaining-hms (org-media-note--seconds-to-timestamp (mpv-get-property "playtime-remaining"))))
            (s-concat icon
                      " org-media-note: "
                      current-timestamp
                      " / "
                      total-timestamp
                      "\t Volume: "
                      (number-to-string volume)
                      "\t Speed: "
                      (number-to-string speed)
                      "\t Remaining: "
                      remaining-hms
                      "\n\t❯ "
                      (if (org-media-note-ref-cite-p)
                          (format "%s (%s)"
                                  title
                                  (org-media-note--current-org-ref-key))
                        (if title
                            (format "%s (%s)" title file-path)
                          file-path))))
        ;; Title when no media is playing
        (concat icon " org-media-note")))))

(defun org-media-note--ui-play-smart-title ()
  (cl-multiple-value-bind (link _ _ _)
      (org-media-note--link-context)
    (cl-multiple-value-bind (ref-mode key _ _)
        (org-media-note--ref-context)
      (cl-multiple-value-bind (_ media-files-in-attach-dir)
          (org-media-note--attach-context)
        (cond
         (link "Open link")
         (ref-mode (format "Open %s" key))
         ((> (length media-files-in-attach-dir) 0) "Open attach")
         (t "Open media"))))))

(defun org-media-note--ui-ab-loop-title ()
  (let ((time-a (mpv-get-property "ab-loop-a"))
        (time-b (mpv-get-property "ab-loop-b")))
    (if (org-media-note--ab-loop-p)
        (concat "Clear AB-loop "
                (org-media-note--ui-hightlight (format "(%s-%s)"
                                                       (org-media-note--seconds-to-timestamp time-a)
                                                       (org-media-note--seconds-to-timestamp time-b))))
      (if (numberp time-a)
          (concat "Set B of AB-loop "
                  (org-media-note--ui-hightlight (format "(%s-)"
                                                         (org-media-note--seconds-to-timestamp time-a))))
        "Set A of AB-loop"))))

(defun org-media-note--ui-toggle-state (var)
  "Get the state of a toggleable variable VAR."
  (org-media-note--ui-hightlight (format "[%s]"
                                         (if (symbol-value var)
                                             "✓"
                                           "✗"))))

(defun org-media-note--ui-hightlight (str)
  (propertize str 'face 'transient-value))

(defun org-media-note--ui-seek-step (&optional in-macro?)
  "Return a formatted string based on the current seek method and value."
  (format "%s%s"
          org-media-note-seek-value
          (cond
           ((eq org-media-note-seek-method 'seconds) "s")
           ((eq org-media-note-seek-method 'percentage)
            (if in-macro? "%%" "%"))
           ((eq org-media-note-seek-method 'frames)
            (if (= org-media-note-seek-value 1)
                " frame"
              " frames")))))

;;;;; Config
(defun org-media-note-toggle-auto-insert-item ()
  "Toggle the automatic insertion of media items."
  (interactive)
  (setq org-media-note-auto-insert-item (not org-media-note-auto-insert-item))
  (org-media-note--update-auto-insert-advice org-media-note-auto-insert-item)
  (message "Auto insert media item: %s" (if org-media-note-auto-insert-item "enabled" "disabled")))

(defun org-media-note-toggle-refcite ()
  "Toggle refcite for links."
  (interactive)
  (if org-media-note-use-refcite-first
      (setq org-media-note-use-refcite-first nil)
    (setq org-media-note-use-refcite-first t)))

(defun org-media-note-toggle-pause-after-insertion ()
  "Toggle pausing after inserting a link."
  (interactive)
  (if org-media-note-pause-after-insert-link
      (setq org-media-note-pause-after-insert-link nil)
    (setq org-media-note-pause-after-insert-link t)))


(defun org-media-note-toggle-save-screenshot ()
  "Toggle `org-media-note-save-screenshot-p'."
  (interactive)
  (if org-media-note-save-screenshot-p
      (setq org-media-note-save-screenshot-p nil)
    (setq org-media-note-save-screenshot-p t)))

(defun org-media-note-toggle-screenshot-with-sub ()
  "Toggle screenshot with sub."
  (interactive)
  (if org-media-note-screenshot-with-sub
      (setq org-media-note-screenshot-with-sub nil)
    (setq org-media-note-screenshot-with-sub t)))

(defun org-media-note-toggle-timestamp-pattern ()
  "Toggle screenshot with sub."
  (interactive)
  (cond
   ((eq org-media-note-timestamp-pattern 'hms)
    (setq org-media-note-timestamp-pattern 'hmsf))
   ((eq org-media-note-timestamp-pattern 'hmsf)
    (setq org-media-note-timestamp-pattern 'hms))))


(defun org-media-note-set-ab-loop-capture-method ()
  "Config the method for capturing AB-loop clips."
  (interactive)
  (let ((choice (org-media-note--select "Capture method: "
                                        '("Always ask" "Select a default"))))
    (if (equal choice "Select a default")
        (progn
          (setq org-media-note-capture-ab-loop-ask-each-time
                nil)
          (let ((selected-function (org-media-note--select-capture-function)))
            (setq org-media-note-default-capture-ab-loop-function-name
                  selected-function)))
      (setq org-media-note-capture-ab-loop-ask-each-time
            t))))

(defun org-media-note-set-separator (new-separator)
  "Set the value of org-media-note-media-note-separator to NEW-SEPARATOR."
  (interactive "sEnter the new separator: ")
  (setq org-media-note-separator-when-merge new-separator)
  (message "org-media-note-media-note-separator set to: %s" org-media-note-separator-when-merge))

(defun org-media-note-set-seek-method ()
  "Config the seek method and value for playback."
  (interactive)
  (let* ((method (org-media-note--select "Select seek method: "
                                         '("seconds" "percentage" "frames")))
         (value (read-number (format "Enter value for %s: " method))))
    (setq org-media-note-seek-method (cond
                                      ((string-equal method "seconds") 'seconds)
                                      ((string-equal method "percentage") 'percentage)
                                      ((string-equal method "frames") 'frames))
          org-media-note-seek-value value))
  (message "Seek method set to: %s."
           (org-media-note--ui-seek-step)))

;;;;; Add note
;;;;;; media note item

(defun org-media-note-insert-link ()
  "Insert current mpv timestamp link into Org-mode note."
  (interactive)
  (let ((point (point)))
    (insert org-media-note-link-prefix
            (format "%s "
                    (org-media-note--link)))
    (when (eq org-media-note-cursor-start-position 'before)
      (goto-char point))
    (when org-media-note-pause-after-insert-link
      (mpv-pause))))

(defun org-media-note--link ()
  "Return media link."
  (cl-multiple-value-bind (file-path filename timestamp)
      (org-media-note--current-media-info)
    (let ((link-type (if (org-media-note-ref-cite-p)
                         (concat (org-media-note--current-media-type)
                                 "cite")
                       (org-media-note--current-media-type))))
      (if (org-media-note--ab-loop-p)
          ;; ab-loop link
          (let ((time-a (org-media-note--seconds-to-timestamp (mpv-get-property "ab-loop-a")))
                (time-b (org-media-note--seconds-to-timestamp (mpv-get-property "ab-loop-b"))))
            (format "[[%s:%s#%s-%s][%s]]"
                    link-type
                    (org-media-note--link-base-file file-path)
                    time-a
                    time-b
                    (org-media-note--link-formatter org-media-note-ab-loop-link-format
                                                    `(("filename" . ,filename)
                                                      ("ab-loop-a" . ,time-a)
                                                      ("ab-loop-b" . ,time-b)
                                                      ("file-path" . ,file-path)))))
        ;; timestamp link
        (format "[[%s:%s#%s][%s]]"
                link-type
                (org-media-note--link-base-file file-path)
                timestamp
                (org-media-note--link-formatter org-media-note-timestamp-link-format
                                                `(("filename" . ,filename)
                                                  ("timestamp" . ,timestamp)
                                                  ("file-path" . ,file-path))))))))

(defun org-media-note--ab-loop-p ()
  "Whether in ab-loop?"
  (let ((time-a (mpv-get-property "ab-loop-a"))
        (time-b (mpv-get-property "ab-loop-b"))
        (pos (mpv-get-playback-position)))
    (and (numberp time-a)
         (numberp time-b)
         (<= time-a pos)
         (<= pos time-b))))

(defun org-media-note--link-base-file (file-path)
  "Return base file for FILE-PATH."
  (if (org-media-note-ref-cite-p)
      (org-media-note--current-org-ref-key)
    (if (org-media-note--online-video-p file-path)
        file-path
      (org-media-note--format-file-path file-path))))

(defun org-media-note--link-formatter (string map)
  "Return a copy of STRING with replacements from MAP.
MAP is an alist in the form of '((PLACEHOLDER . REPLACEMENT))
Each placeholder can be a string, symbol, or number.
REPLACEMENT can be a string, a number, symbol, or function. Replace all
occurrences of %-escaped PLACEHOLDER with replacement and return a new string.

  For example:
  (let ((input-string  \"Words,  %test1%test2 more words %test1.\")
        (map '((test1 . \"asdf\")
               (test2 . \"zxcv\"))))
    (org-media-note--link-formatter input-string map))

  Returns:
  \"Words,  asdfzxcv more words asdf.\""
  (cl-loop for (holder . replacement) in map
           when replacement
           do (setq string
                    (replace-regexp-in-string
                     (concat "%"
                             (pcase holder
                               ((pred symbolp) (symbol-name holder))
                               ((pred stringp) holder)
                               ((pred numberp) (number-to-string holder))
                               ((pred functionp) (funcall replacement))))
                     (pcase replacement
                       ((pred symbolp) (symbol-name holder))
                       ((pred stringp) replacement)
                       ((pred numberp) (number-to-string replacement))
                       ((pred functionp) (funcall replacement))
                       (_ ""))
                     string))
           finally return string))

(defun org-media-note--beginning-of-line-advice (orig-func &optional n)
  "Advice to optimize line beginning detection in plain-lists.
- ORIG-FUNC: `org-beginning-of-line'.
- N: move forward N - 1 lines first."
  (let ((org-list-full-item-re org-media-note--list-full-item-re))
    (funcall orig-func n)))

(defun org-media-note--insert-item-advice (orig-fn &rest args)
  "When item begins with media link, insert playback position.
Pass ARGS to ORIG-FN, `org-insert-item'."
  (interactive "P")
  (let ((itemp (org-in-item-p))
        (pos (point)))
    ;; return nil, if either condition matched:
    ;; 1. cursor isn't in a list
    ;; 2. list is invisible
    ;; 3. no playing media
    (unless (or (not itemp)
                (not (mpv-get-property "path"))
                (save-excursion
                  (goto-char itemp)
                  (org-invisible-p)))
      (if (save-excursion
            (goto-char itemp)
            (org-media-note--at-media-item-p))
          (progn
            (org-media-note-item)
            t)))))

(defun org-media-note--at-media-item-p ()
  "Is point at a line starting a plain list item with a media-note link?"
  (or (org-list-at-regexp-after-bullet-p "\\(\\[\\[video.+\\)")
      (org-list-at-regexp-after-bullet-p "\\(\\[\\[audio.+\\)")))

(defun org-media-note-item ()
  "Insert a item with the link to media file."
  (interactive "P")
  (let ((itemp (org-in-item-p))
        (pos (point)))
    (cond
     ;; In a media note list and media file is open: insert with `org-list-insert-item',
     ((and itemp
           (goto-char itemp)
           (org-media-note--at-media-item-p)
           (mpv-get-property "path"))
      (let* ((struct (org-list-struct))
             (prevs (org-list-prevs-alist struct))
             (s (concat (org-media-note--link)
                        " ")))
        (setq struct (org-list-insert-item pos struct prevs nil
                                           s))
        (org-list-write-struct struct
                               (org-list-parents-alist struct))
        (looking-at org-list-full-item-re)
        (move-end-of-line 1)
        (when org-media-note-pause-after-insert-link
          (mpv-pause))
        (when org-media-note-save-screenshot-p
          (org-media-note-insert-screenshot))))
     ;; In a list of another type, don't break anything: throw an error.
     (t (error (concat "No playing media file now. Please open the media file"
                       "first if you want to insert media note,"
                       "\nor maybe you want to turn off <Auto insert media item>."))))))

(defun org-media-note-merge-item ()
  "Join multiple lines of item into a single line."
  (interactive)
  (if (use-region-p)
      (let* ((begin (region-beginning))
             (end (region-end))
             (text (buffer-substring-no-properties begin end))
             (lines (split-string text "\n" t))
             (reformatted-lines (mapcar
                                 (lambda (line)
                                   (if (string-match (format ".+\\(%s\\) ?\\(.*\\)$" org-media-note--link-pattern) line)
                                       (match-string 2 line)
                                     line))
                                 (cdr lines)))) ;; reformatted from the second line.
        (delete-region begin end)
        (insert (concat (car lines) org-media-note-separator-when-merge (mapconcat 'identity reformatted-lines org-media-note-separator-when-merge)))
        (deactivate-mark))
    (message "No region selected!")))

;;;;;; screenshot
(defun org-media-note-insert-screenshot ()
  "Insert current mpv screenshot into Org-mode note."
  (interactive)
  (cl-multiple-value-bind (media-path media-title current-timestamp)
      (org-media-note--current-media-info)
    (let* ((image-file-name (funcall org-media-note-capture-name-function
                                     media-path media-title current-timestamp nil org-media-note-screenshot-extension))
           (image-target-path (org-media-note--output-file-path image-file-name media-path media-title)))
      (if org-media-note-screenshot-with-sub
          (mpv-run-command "screenshot-to-file" image-target-path)
        (mpv-run-command "screenshot-to-file" image-target-path
                         "video"))
      (org-media-note--insert-file-link image-target-path)
      (org-media-note--display-inline-images))))

(defun org-media-note--display-inline-images ()
  "Redisplay inline images."
  (when org-media-note-display-inline-images
    ;; TODO Avoid sleeping here?
    (sleep-for 0.1)
    (org-display-inline-images)))

;;;;;; ab-loop clip
(defun org-media-note-capture-ab-loop-default (time-a time-b input-file output-file-sans-ext)
  "Capture a video segment from TIME-A to TIME-B of INPUT-FILE.
Generate OUTPUT-FILE from OUTPUT-FILE-SANS-EXT and return it."
  (let* ((output-file (concat output-file-sans-ext "." (or (file-name-extension input-file) "mp4")))
         (command (if (org-media-note--online-video-p input-file)
                      (format "yt-dlp \"%s\" --downloader ffmpeg --downloader-args \"ffmpeg_i: -ss %s -to %s\" -o \"%s\""
                              input-file time-a time-b output-file)
                    (format "ffmpeg -ss %s -to %s -i \"%s\" -c copy \"%s\""
                            time-a time-b input-file output-file))))
    (async-shell-command command)
    output-file))

(defun org-media-note-capture-ab-loop-to-gif (time-a time-b input-file output-file-sans-ext)
  "Capture a segment from TIME-A to TIME-B of INPUT-FILE and convert it to GIF.
Generate OUTPUT-FILE from OUTPUT-FILE-SANS-EXT and return it."
  (let* ((output-file (concat output-file-sans-ext ".gif"))
         (command (if (org-media-note--online-video-p input-file)
                      (format "yt-dlp \"%s\" --downloader ffmpeg --downloader-args \"ffmpeg_i: -ss %s -to %s\" -o - | ffmpeg -i - \"%s\""
                              input-file time-a time-b output-file)
                    (format "ffmpeg -ss %s -to %s -i \"%s\" -vf \"fps=10,scale=512:-1:flags=lanczos\" -c:v gif -f gif \"%s\""
                            time-a time-b input-file output-file))))
    (async-shell-command command)
    output-file))

(defun org-media-note-capture-ab-loop-and-insert ()
  "Capture ab-loop segment, then insert it at the cursor position."
  (interactive)
  (cl-multiple-value-bind (media-path media-title _)
      (org-media-note--current-media-info)
    (let* ((time-a (org-media-note--seconds-to-timestamp (mpv-get-property "ab-loop-a")))
           (time-b (org-media-note--seconds-to-timestamp (mpv-get-property "ab-loop-b")))
           (capture-function-name (if org-media-note-capture-ab-loop-ask-each-time
                                      (org-media-note--select-capture-function)
                                    org-media-note-default-capture-ab-loop-function-name))
           (capture-function (cdr (assoc capture-function-name
                                         org-media-note-capture-ab-loop-functions-alist)))
           (output-file-name (funcall org-media-note-capture-name-function
                                      media-path media-title time-a time-b ".xxx"))
           ;; real ext is generated in capture-function
           (output-file-path-sans-ext (file-name-sans-extension (org-media-note--output-file-path output-file-name
                                                                                                  media-path media-title)))
           (output-file (funcall capture-function time-a time-b media-path output-file-path-sans-ext)))
      (org-media-note--insert-file-link output-file))))

(defun org-media-note--select-capture-function ()
  "Select capture function name from `org-media-note-capture-ab-loop-functions-alist'."
  (let ((choices (mapcar #'car org-media-note-capture-ab-loop-functions-alist)))
    (org-media-note--select "Select capture function: " choices)))

;;;;;; sub-text
(defun org-media-note-insert-sub-text ()
  "Insert subtitle text."
  (interactive)
  (let ((sub-text (condition-case nil
                      (mpv-get-property "sub-text")
                    (error nil))))
    (if sub-text
        (insert sub-text)
      (message "No subtitles found in current file."))))
;;;;; Adjust timestamp

(defun org-media-note-adjust-timestamp-offset ()
  "Adjust all timestamps within the current heading.
Aligns them to the current playing position in mpv."
  (interactive)
  (let ((current-playing-position (mpv-get-playback-position))
        (link (org-element-property :raw-link (org-element-context))))
    (unless current-playing-position
      (error "Please use this function while mpv is playing"))
    (unless link
      (error "Please place the cursor on a media-link"))
    (let* ((splitted (split-string link "#"))
           (timestamps (split-string (nth 1 splitted)))
           (current-link-position (org-timer-hms-to-secs (nth 0 timestamps)))
           (offset (- current-playing-position current-link-position)))
      (save-excursion
        (org-narrow-to-subtree)
        (goto-char (point-min))
        (while (re-search-forward org-media-note--hms-timestamp-pattern
                                  nil t)
          (let* ((beg (match-beginning 1))
                 (end (match-end 1))
                 (hms (buffer-substring beg end))
                 (adjusted-hms (org-media-note--seconds-to-hms (+ (org-timer-hms-to-secs hms)
                                                                  offset))))
            (goto-char beg)
            (delete-region beg end)
            (insert adjusted-hms)))
        (widen)))))

;;;;; Jump to the right position
(defun org-media-note--open (link)
  "Open media LINK.
Supported formats:
- video:example.mkv#0:02:13
  jump to 0:02:13
- video:example.mkv#0:02:13-0:02:20
  jump to 0:02:13 and loop between 0:02:13 and 0:02:20."
  (cl-multiple-value-bind (file-path-or-url time-a time-b)
      (org-media-note--split-link link)
    (org-media-note--follow-link file-path-or-url
                                 time-a time-b)))

(defun org-media-note--follow-link (file-path-or-url &optional time-a time-b)
  "Open FILE-PATH-OR-URL in mpv.
TIME-A and TIME-B indicate the start and end of a playback loop."
  (let* ((online-video-p (if (org-media-note--online-video-p file-path-or-url)
                             (if (executable-find "yt-dlp")
                                 t
                               (error (concat "Warning: mpv needs the yt-dlp to play online videos."
                                              "yt-dlp-danmaku is also needed if you want bilibili danmaku.")))
                           nil))
         (path (if online-video-p
                   (org-media-note--remove-utm-parameters file-path-or-url)
                 (expand-file-name file-path-or-url))))
    (if (not (string= path
                      (mpv-get-property "path")))
        ;; file-path is not playing
        (progn
          (if time-a
              (message "open %s@t=%s..." path time-a)
            (message "open %s..." path))
          (apply 'mpv-start
                 path
                 (org-media-note--build-mpv-args path time-a
                                                 time-b)))
      ;; file-path is playing
      (org-media-note--seek-position-in-current-media-file
       time-a time-b))))

(defun org-media-note--build-mpv-args (path time-a time-b)
  "Build the argument list for `mpv-start`."
  (let ((extra-mpv-options (org-media-note--mpv-options path)))
    (append (when time-a
              (list (concat "--start=+" time-a)))
            (when time-b
              (list (concat "--ab-loop-a=" time-a)
                    (concat "--ab-loop-b=" time-b)))
            extra-mpv-options)))

(defun org-media-note--mpv-options (media-path)
  "Get mpv options for `MEDIA-PATH'.
Combine the following options:
1. `org-media-note-mpv-general-options',
2. `org-media-note-mpv-online-website-options-alist',
3. If `org-media-note-mpv-webstream-download-path' non-nil, set as paths for yt-dlp."
  (let* ((online-video-p (org-media-note--online-video-p media-path))
         (website-options (when online-video-p
                            (cdr (seq-find (lambda (pair)
                                             (string-match-p (car pair)
                                                             media-path))
                                           org-media-note-mpv-online-website-options-alist))))
         (download-path-option (when (and online-video-p org-media-note-mpv-webstream-download-path)
                                 (list (format "--ytdl-raw-options=paths=%s" org-media-note-mpv-webstream-download-path))))
         (raw-options (append org-media-note-mpv-general-options
                              website-options download-path-option))
         ;; for those key-value pair options, better to consolidate them to avoid strange behavior.
         (option-keys '("--ytdl-raw-options=" "--vd-lavc-o=" "--ad-lavc-o="
                        "--demuxer-lavf-o="))
         key-value-options-alist
         other-options)
    ;; Separate recognized options for consolidation
    (dolist (option raw-options)
      (if-let ((key (seq-find (lambda (key)
                                (string-prefix-p key option))
                              option-keys)))
          (let* ((pair (assoc key key-value-options-alist))
                 (values (cdr pair))
                 (option-values (string-replace key "" option))
                 (new-value (string-replace ",,"
                                            ","
                                            (concat (when values (concat values ",")) option-values)
                                            )))
            (if pair
                (setcdr pair new-value)
              (add-to-list 'key-value-options-alist
                           (cons key new-value))))
        (push option other-options)))
    ;; Combine all options together
    (append other-options
            (mapcar (lambda (option)
                      (concat (car option)
                              (cdr option)))
                    key-value-options-alist))))

(defun org-media-note-goto-timestamp ()
  "Seek media to position in timestamp at point."
  (interactive)
  (let ((line (thing-at-point 'line t))
        timestamp)
    (save-match-data (and (string-match org-media-note--hms-timestamp-pattern
                                        line)
                          (setq timestamp (match-string 1 line))))
    (if (not timestamp)
        ;; TODO refers to `run-at-time'
        (setq timestamp (read-string "Enter timestamp: "))
      )
    (org-media-note--seek-position-in-current-media-file (org-timer-hms-to-secs timestamp))))

(defun org-media-note--seek-position-in-current-media-file (time-a &optional time-b)
  "Seek position to TIME-A.
If TIME-B is non-nil, loop media between TIME-A and TIME-B."
  ;; TODO clear a-b loop when only one timestamp?
  (when time-b
    (mpv-set-property "ab-loop-a" time-a)
    (mpv-set-property "ab-loop-b" time-b))
  (mpv-seek time-a))

;;;;; Online URL

(defun org-media-note--remove-utm-parameters (url)
  "Remove utm parameters from the given URL."
  (let* ((parsed-url (url-generic-parse-url url))
         (query (url-filename parsed-url))
         (split-query (split-string query "\\?"))
         (base-path (car split-query))
         (params (if (cdr split-query) (split-string (cadr split-query) "&") nil))
         (filtered-params (when params
                            (seq-filter (lambda (param)
                                          (not (seq-some (lambda (pattern)
                                                           (string-match-p (concat "^" pattern) param))
                                                         org-media-note-utm-parameter-patterns)))
                                        params)))
         (clean-query (if filtered-params
                          (concat "?" (string-join filtered-params "&"))
                        "")))
    (setf (url-filename parsed-url) (concat base-path clean-query))
    (url-recreate-url parsed-url)))

(defun org-media-note--generate-url-with-timestamp (path)
  "Generate new URL with timestamp from PATH."
  (cl-multiple-value-bind (file-path-or-url time-a time-b)
      (org-media-note--split-link path)
    (let* ((url (org-media-note--remove-utm-parameters file-path-or-url))
           (seconds (org-media-note--timestamp-to-seconds time-a
                                                          t))
           (param-separator (if (string-match-p "\\?" url)
                                "&"
                              "?")))
      (format "%s%st=%s" url param-separator seconds))))

(defun org-media-note--url-at-point ()
  "Retrieve the URL with timestamp at point."
  (let* ((link (org-element-context))
         (type (org-element-property :type link))
         (path (org-element-property :path link)))
    (cond
     ((and (member type '("audio" "video"))
           (org-media-note--online-video-p path))
      (org-media-note--generate-url-with-timestamp
       path))
     ((member type '("audiocite" "videocite"))
      (let* ((key (nth 0
                       (split-string path "#")))
             (url (org-media-note-cite--url key)))
        (if url url nil)))
     (t nil))))

(defun org-media-note-open-url-at-point ()
  "Open the URL with timestamp at point."
  (interactive)
  (let ((url (org-media-note--url-at-point)))
    (if url
        (browse-url url)
      (message "Please place cursor at a timestamp link of online media."))))


(defun org-media-note-copy-mpv-command ()
  "Copy the mpv command to play media at point."
  (interactive)
  (let* ((link (org-element-context))
         (type (org-element-property :type link)))
    (cl-multiple-value-bind (key-or-path time-a time-b)
        (org-media-note--split-link (org-element-property :path link))
      (let* ((path (cond
                    ((org-media-note--online-video-p key-or-path)
                     (org-media-note--remove-utm-parameters
                      key-or-path))
                    ((member type '("audiocite" "videocite"))
                     (org-media-note-cite--path key-or-path))
                    (t key-or-path)))
             (mpv-args (org-media-note--build-mpv-args path time-a
                                                       time-b))
             (command (concat (format "mpv \"%s\" " path)
                              (mapconcat 'identity mpv-args " "))))
        (kill-new command)
        (message (format "Copied: %s" command))))))

;;;; Footer
(provide 'org-media-note-core)
;;; org-media-note-core.el ends here
