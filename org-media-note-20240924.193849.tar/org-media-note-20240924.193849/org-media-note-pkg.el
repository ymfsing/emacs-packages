(define-package "org-media-note" "20240924.193849" "Take video and audio notes with Org-mode"
  '((emacs "24.4")
    (org "9.3")
    (transient "0.1.0")
    (mpv "0.2.0"))
  :authors
  '(("Yuchen Lea" . "yuchen.lea@gmail.com"))
  :maintainer
  '("Yuchen Lea" . "yuchen.lea@gmail.com")
  :keywords
  '("note-taking" "multimedia" "video")
  :url "https://github.com/yuchen-lea/org-media-note")
;; Local Variables:
;; no-byte-compile: t
;; End:
