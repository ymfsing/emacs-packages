;;; Generated package description from thing-edit.el  -*- no-byte-compile: t -*-
(define-package "thing-edit" "20240627.183039" "Extension thing edit" 'nil :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com")) :maintainer '("Andy Stewart" . "lazycat.manatee@gmail.com") :keywords '("thingatpt" "edit") :url "http://www.emacswiki.org/emacs/download/thing-edit.el")
