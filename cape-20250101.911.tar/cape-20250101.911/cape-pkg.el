;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20250101.911"
  "Completion At Point Extensions."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "2c4ed619518aeae22d2ea58bdff42efb1efa0a43"
  :revdesc "2c4ed619518a"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
