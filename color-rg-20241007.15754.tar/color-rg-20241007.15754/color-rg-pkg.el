;;; Generated package description from color-rg.el  -*- no-byte-compile: t -*-
(define-package "color-rg" "20241007.15754" "Search and refacotry code with rg" 'nil :authors '(("Andy Stewart" . "lazycat.manatee@gmail.com")) :maintainer '("Andy Stewart" . "lazycat.manatee@gmail.com") :url "http://www.emacswiki.org/emacs/download/color-rg.el")
