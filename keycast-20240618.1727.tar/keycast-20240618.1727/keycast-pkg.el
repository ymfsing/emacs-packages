(define-package "keycast" "20240618.1727" "Show current command and its binding"
  '((emacs "25.3")
    (compat "29.1.4.5"))
  :commit "f04466cd8f8226715f113635204dc978171f63b7" :authors
  '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")
  :keywords
  '("multimedia")
  :url "https://github.com/tarsius/keycast")
;; Local Variables:
;; no-byte-compile: t
;; End:
