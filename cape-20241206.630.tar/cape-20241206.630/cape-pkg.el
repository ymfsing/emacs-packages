;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20241206.630"
  "Completion At Point Extensions."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "ae094a665438a5d65b52b3d2a538c17998770b78"
  :revdesc "ae094a665438"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
