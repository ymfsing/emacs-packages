(define-package "osx-dictionary" "20240226.511" "Interface for OSX Dictionary.app"
  '((cl-lib "0.5"))
  :commit "8f16ffb465b64c9dd566c8b7316b34896ce4c52b" :authors
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers
  '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainer
  '("Chunyang Xu" . "mail@xuchunyang.me")
  :keywords
  '("mac" "dictionary")
  :url "https://github.com/xuchunyang/osx-dictionary.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
