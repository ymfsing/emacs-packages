(define-package "devdocs-browser" "20231231.1455" "Browse devdocs.io documents using EWW"
  '((emacs "27.1"))
  :commit "afc460e687bec4eb947ab85d207778fc3b9b3bbc" :authors
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainers
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainer
  '("blahgeek" . "i@blahgeek.com")
  :keywords
  '("docs" "help" "tools")
  :url "https://github.com/blahgeek/emacs-devdocs-browser")
;; Local Variables:
;; no-byte-compile: t
;; End:
