(define-package "habitica" "20240601.2029" "Interface for habitica.com"
  '((org "8.3.5")
    (emacs "24.3"))
  :commit "b884301058c075e6f530f10e970b744aa29f5937" :authors
  '(("Adrien Brochard"))
  :maintainers
  '(("Adrien Brochard"))
  :maintainer
  '("Adrien Brochard")
  :keywords
  '("habitica" "todo")
  :url "https://github.com/abrochard/emacs-habitica")
;; Local Variables:
;; no-byte-compile: t
;; End:
