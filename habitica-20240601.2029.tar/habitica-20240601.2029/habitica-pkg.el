;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "habitica" "20240601.2029"
  "Interface for habitica.com."
  '((org   "8.3.5")
    (emacs "24.3"))
  :url "https://github.com/abrochard/emacs-habitica"
  :commit "b884301058c075e6f530f10e970b744aa29f5937"
  :revdesc "b884301058c0"
  :keywords '("habitica" "todo"))
