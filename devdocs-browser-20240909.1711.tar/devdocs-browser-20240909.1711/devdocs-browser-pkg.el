;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devdocs-browser" "20240909.1711"
  "Browse devdocs.io documents using EWW."
  '((emacs "27.1"))
  :url "https://github.com/blahgeek/emacs-devdocs-browser"
  :commit "3de7b1f013cbecebedeeeb16d5fec532ef56c2e2"
  :revdesc "3de7b1f013cb"
  :keywords '("docs" "help" "tools")
  :authors '(("blahgeek" . "i@blahgeek.com"))
  :maintainers '(("blahgeek" . "i@blahgeek.com")))
