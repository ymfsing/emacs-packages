;;; Generated package description from auto-save.el  -*- no-byte-compile: t -*-
(define-package "auto-save" "20220720.212103" "Auto save files when idle" 'nil :authors '((nil . "AndyStewartlazycat.manatee@gmail.com")) :maintainer '(nil . "AndyStewartlazycat.manatee@gmail.com") :keywords '("autosave"))
