(define-package "org-media-note" "20240620.163846" "Take video and audio notes with Org-mode"
  '((emacs "27.1")
    (mpv "0.2.0")
    (pretty-hydra "0.2.2"))
  :authors
  '(("Yuchen Lea" . "yuchen.lea@gmail.com"))
  :maintainer
  '("Yuchen Lea" . "yuchen.lea@gmail.com")
  :keywords
  '("note-taking" "multimedia" "video")
  :url "https://github.com/yuchen-lea/org-media-note")
;; Local Variables:
;; no-byte-compile: t
;; End:
