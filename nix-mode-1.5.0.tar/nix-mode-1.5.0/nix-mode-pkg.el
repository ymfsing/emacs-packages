;; Generated package description from nix-mode.el  -*- no-byte-compile: t -*-
(define-package "nix-mode" "1.5.0" "Major mode for editing .nix files" '((emacs "25.1") (magit-section "0") (transient "0.3")) :commit "54e5626829168e22126b233e079f04dff3c71b90" :maintainer '("Matthew Bauer" . "mjbauer95@gmail.com") :keywords '("nix" "languages" "tools" "unix") :url "https://github.com/NixOS/nix-mode")
