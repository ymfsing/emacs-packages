;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20241122.614"
  "Minor mode for making Anki cards with Org."
  '((emacs "25.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "32706314adf6d02a407f2b0b411741d9c4722c05"
  :revdesc "32706314adf6")
