;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241207.1804"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "5caf67192feef3ab39ee85d09e7b6491cc6af104"
  :revdesc "5caf67192fee"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
