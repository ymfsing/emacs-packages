;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241213.1040"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "f74017c172167edbe15bf7a922a6313c7aa848bd"
  :revdesc "f74017c17216"
  :keywords '("convenience" "modal-editing"))
