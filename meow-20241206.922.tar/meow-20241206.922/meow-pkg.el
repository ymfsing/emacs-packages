;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241206.922"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "73f2dd2fce8069c4ac4f6ae2a8afdda40450a7e4"
  :revdesc "73f2dd2fce80"
  :keywords '("convenience" "modal-editing"))
