(define-package "org-media-note" "20220612.224334" "Take video and audio notes with Org-mode"
  '((emacs "27.1")
    (mpv "0.1.0")
    (pretty-hydra "0.2.2"))
  :authors
  '(("Yuchen Lea" . "yuchen.lea@gmail.com"))
  :maintainer
  '("Yuchen Lea" . "yuchen.lea@gmail.com")
  :url "https://github.com/yuchen-lea/org-media-note")
;; Local Variables:
;; no-byte-compile: t
;; End:
