(define-package "habitica" "20220215.1758" "Interface for habitica.com"
  '((org "8.3.5")
    (emacs "24.3"))
  :commit "9e1fde7f359f7f6a6976b857fbbdbc8dd4fd3327" :authors
  '(("Adrien Brochard"))
  :maintainers
  '(("Adrien Brochard"))
  :maintainer
  '("Adrien Brochard")
  :keywords
  '("habitica" "todo")
  :url "https://github.com/abrochard/emacs-habitica")
;; Local Variables:
;; no-byte-compile: t
;; End:
