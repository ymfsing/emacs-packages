;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20250722.1033"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "716f1c32a22dc6dcc0a33874facd0fbc033de52a"
  :revdesc "716f1c32a22d"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
