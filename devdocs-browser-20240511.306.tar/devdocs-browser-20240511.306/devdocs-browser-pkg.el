(define-package "devdocs-browser" "20240511.306" "Browse devdocs.io documents using EWW"
  '((emacs "27.1"))
  :commit "0655b89651458777354a3b89c1d486e0fda1928d" :authors
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainers
  '(("blahgeek" . "i@blahgeek.com"))
  :maintainer
  '("blahgeek" . "i@blahgeek.com")
  :keywords
  '("docs" "help" "tools")
  :url "https://github.com/blahgeek/emacs-devdocs-browser")
;; Local Variables:
;; no-byte-compile: t
;; End:
